<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="style.css">
	<title>HTML</title>
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,400,300,700,600' rel='stylesheet' type='text/css'>
</head>
<body>
	<div class="header-area">	
		<div class="container clear">
		
			<div class="logo">	
				<a href="#"></a>

			</div>
			<div class="social-icons">
				<ul class="contact-info clear">
					<li><span class="email"></span>Istansau@yahoo.com</a></li>
					<li><span class="phone"></span>+8801681411568</li>
				</ul>
				<ul class="social-links clear">
					<li class="facebook"><a href="https://www.facebook.com/tanvir.pele"></a></li>
					<li class="twitter"><a href="#">twitter</a></li>
					<li class="linked-in"><a href="#">linked In</a></li>
					<li class="pinterest"><a href="#">Pinterest</a></li>
					<li class="stumbleupon"><a href="#">stumbleupon</a></li>
					<li class="times"><a href="#">times</a></li>
					<li class="fox"><a href="#">Pinterest</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="menu-area">
		<div class="container">
			<div class="mainmenu">
				<ul class="nav clear">
				<li>
						<a href="home.php">HOME</a>
					</li>
					<li>
						<a href="admin.php">ADMIN</a>
					</li>
					<li>
						<a href="user.html">My Account</a>
					</li>
					<li>
						<a href="noticeview.php">Notice</a>
					</li>

					<li>
						<a href="employeeinfo.php">info</a>
					</li>
					
					
						
					<li>
						<a href="noticeview.php">view</a>
					</li>
					<li>


					<a href="login.php">logout</a>
				</li>
				</ul>
			</div>
		</div>
	</div>

				<ul>
					<li>
						<a href="employeeinformation.php">view information</a>
					</li>
						
					<li>
						<a href="noticeview.php">Notice</a>
					</li>
					
				</ul>
					
	

</body>
</html>


<?php

include("connect.php");
if(isset($_POST['register']))
{
	$sql = "INSERT INTO  employeenotice(EmployId,Notice) Values
	($_POST[mail_id],'$_POST[mail]')";
	
if(!mysql_query($sql))
	{
		//echo("go");
		die('Errorshow:  '.mysql_error());
	}else{
		//echo("successfully inserted");
		echo'<script type="text/javascript">';
        echo'alert ("successfully inserted");';
       echo"</script>"; 

      }	
	
}else{
	
}