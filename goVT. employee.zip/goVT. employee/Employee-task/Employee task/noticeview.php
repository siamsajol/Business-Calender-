<html>
<head>

</head>


<body>

<div align="right" style="margin: 20px;">
	
	<a href="login.php">logout</a>
	<a href="employeeinfo.php">Home</a>
	
</div>

<div align="center">

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

<div align="left" style="margin: 30px;">
<p style='color: black; font-size: 25px;'><b>Notice view</b></p>
<br></br>
EmployeeId: <input type="text" name="mail_id" placeholder="give your Employee id"/></br>
</br>
<input type="submit" value="Send" name="send"></div>

</form>


</div>

</body>
</html>

<?php 

include("connect.php");
if(isset($_POST['send'])){
	$s =$_POST['mail_id'];
	$sqldep = mysql_query("select Notice from employeenotice where EmployId=$s");

	while ($_GET = mysql_fetch_array($sqldep,MYSQL_ASSOC)){
		$regfee= $_GET['Notice'];
		

	}
	 echo"<p style='color: black; font-size: 20px;'>"."<b>Latest notice:  ".$regfee."</b></p>";
	 echo "<br></br>";
}
?>