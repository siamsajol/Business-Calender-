<?php
mysql_connect("localhost","root","") or die (mysql_error());
if(!mysql_connect("localhost","root",""))
{
die('Could NOt Connect'.mysql_error());
}
mysql_select_db("shiam") or die ("not connect  ".mysql_error());



?>
