<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Employee Registration</title>
</head>
<body>

    	
   <div align="right" style="margin: 20px;">
	<a href="login.php">logout</a>
	<a href="admin.php">Home</a>
	
</div>
            	    
                              
            
        

<h1>Employee Registration</h1>
<div align="center">
<br></br>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<table >

<tr>
<td width="100" height="40">EmployeeID:</td>
<td ><input type="text" name="eid" placeholder="give Employe id"/></td>
</tr>

<tr>
<td width="100" height="40">UserPassword: </td>
<td><input type="text" name="upass" placeholder="password"/></td>
</tr>


<tr>
<td width="100" height="40">Email: </td>
<td><input type="text" name="email" placeholder="email"/></td>
</tr>

<tr>
<td width="100" height="40">Firstname: </td>
<td><input type="text" name="fname"  placeholder="give first name"/></td>
</tr>

<tr>
<td width="100" height="40">Lastname: </td>
<td><input type="text" name="lname" placeholder="give last name"/></td>
</tr>

<tr>
<td width="100" height="40">User name: </td>
<td><input type="text" name="uname" placeholder="user name"/></td>
</tr>

<tr>
<td width="100" height="40">Date of Birth: </td>
<td><input type="text" name="dob" placeholder="yyyy/mm/dd"/></td>
</tr>

<tr>
<td width="100" height="40">Address: </td>
<td><input type="text" name="addrs" placeholder="give address"/></td>
</tr>


<tr>
<td width="100" height="40">PhoneNo: </td>
<td><input type="text" name="phn" placeholder="give phone no"/></td>
</tr>

<tr>
<td width="100" height="40">Education </td>
<td><input type="text" name="ed" placeholder="give Education status"/></td>
</tr>

<tr>
<td width="100" height="40">Recruitment: </td>
<td><input type="text" name="rct" placeholder="yyyy/mm/dd"/></td>
</tr>

<tr>
<td width="100" height="40">DepartmentId: </td>
<td><input type="text" name="drt" placeholder="give Department Id"/></td>
</tr>

<tr>
<td width="100" height="40">Transfer: </td>
<td><input type="text" name="trs" placeholder="Transfer zone"/></td>
</tr>


<tr>
<td width="100" height="40">Starting salary: </td>
<td><input type="text" name="sts" placeholder="Starting salary"/></td>
</tr>

<tr>
<td width="100" height="40">current salary: </td>
<td><input type="text" name="cts" placeholder="current salary at taka"/></td>
</tr>

<tr>
<td width="100" height="40">Pension Money: </td>
<td><input type="text" name="pmn" placeholder="give pension money at taka"/></td>
</tr>

<tr>
<td width="100" height="40">Past Record </td>
<td><input type="text" name="prs" placeholder="give record"/></td>
</tr>

<tr>
<td width="100" height="40">Status: </td>
<td><input type="text" name="stas" placeholder="status for this employee"/></td>
</tr>


<tr>
<td width="100" height="40"><input type="submit" name ="registration" value="Register"></td></table>
</tr>
</form>

</div>
</div>
<br></br>


</body>
</html>





<?php
include("connect.php");

if(isset($_POST['registration']))
{
	
	 
	$sql = "INSERT INTO  employee1(EmployeeID,UserPassword,Email,FirstName,LastName,UserName,DateOfBirtth,Address
	,PhoneNo,Education,Recruitment,DepartmentID,Transfer,StartingSalary,CurrentSalary,PensionMoney,PastRecord,Status)
	 Values
	($_POST[eid],'$_POST[upass]','$_POST[email]','$_POST[fname]','$_POST[lname]','$_POST[uname]','$_POST[dob]',
	'$_POST[addrs]',$_POST[phn],'$_POST[ed]','$_POST[rct]',$_POST[drt],'$_POST[trs]',
	'$_POST[sts]','$_POST[cts]','$_POST[pmn]','$_POST[prs]','$_POST[stas]')";
	
if(!mysql_query($sql))
	{
		//echo("go");
		die('Errorshow:  '.mysql_error());
	}else{
		//echo("successfully inserted");
		echo'<script type="text/javascript">';
        echo'alert ("successfully inserted");';
       echo"</script>"; 

      }
      
}


?>
