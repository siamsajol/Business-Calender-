<html>
<head>
<title>total details view</title>


</head>
<body>

<div align="right" style="margin: 20px;">
	
	<a href="login.php">logout</a>
	<a href="employeeinfo.php">Home</a>
	
</div>




<div >

<h1>Employee DETAILS</h1>

</div>


<div align=left style="margin: 20px;">

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<p><b>EmployeeId:</b><input type="text" name="id" placeholder="give employee id"></p>
<p><input type="submit" name="son" value="Enter"></p>
</form>

</div>

</body>
</html>

<?php


include("connect.php");
if(isset($_POST['son'])){

	$password;
	$email ;
	$username;
	$dateofbirth;
	$address;
	$phoneno;
	$recruitment;
	$transfer;
	$startsalary;
	$currentsalary;
	$pensionmoney;
	$pastrecord;
	$status;
	
	$id =$_POST['id'];
	$sql=mysql_query("select EmployeeID,UserPassword,Email,UserName,DateOfBirtth,Address,PhoneNo,Recruitment,
	Transfer,StartingSalary,CurrentSalary,PensionMoney,PastRecord,Status from employee1 where EmployeeID=$id");
	
if($sql === FALSE) { 
    die(mysql_error()); // TODO: better error handling
    
}
	while ($_GET = mysql_fetch_array($sql,MYSQL_ASSOC)){
		$id = $_GET['EmployeeID'];
		$password = $_GET['UserPassword'];
		$email =$_GET['Email'];
		$username =$_GET['UserName'];
		$dateofbirth = $_GET['DateOfBirtth'];
		$address = $_GET['Address'];
		$phoneno = $_GET['PhoneNo'];
		$recruitment =$_GET['Recruitment'];
		$transfer = $_GET['Transfer'];
		$startsalary = $_GET['StartingSalary'];
		$currentsalary = $_GET['CurrentSalary'];
		$pensionmoney = $_GET['PensionMoney'];
		$pastrecord = $_GET['PastRecord'];
		$status = $_GET['Status'];
						
	}


	echo"<br></br>";
	echo'<div align="left" style="margin: 25px;">';
	echo "<p style='color: black; font-size: 25px;'>"."<b>EmployeeId:  ".$id."</b></p>";
	echo"<p style='color: black; font-size: 25px;'>"."<b>Password: ".$password."</b></p>";
	echo "<p style='color: black; font-size: 25px;'>"."<b>Email: ".$email."</b></p>";
	echo "<p style='color: black; font-size: 25px;'>"."<b>Username: ".$username."</b></p>";
	echo "<p style='color: black; font-size: 25px;'>"."<b>Dateofbirth: ".$dateofbirth."</b></p>";
	echo "<p style='color: black; font-size: 25px;'>"."<b>Address: ".$address."</b></p>";
	echo "<p style='color: black; font-size: 25px;'>"."<b>Phoneno: ".$phoneno."</b></p>";
	echo "<p style='color: black; font-size: 25px;'>"."<b>Recruitment: ".$recruitment."</b></p>";
	echo "<p style='color: black; font-size: 25px;'>"."<b>Transfer: ".$transfer."</b></p>";
	echo "<p style='color: black; font-size: 25px;'>"."<b>Startsalary: ".$startsalary."</b></p>";
	echo "<p style='color: black; font-size: 25px;'>"."<b>Currentsalary: ".$currentsalary."</b></p>";
	echo "<p style='color: black; font-size: 25px;'>"."<b>Pension Money: ".$pensionmoney."</b></p>";
	echo "<p style='color: black; font-size: 25px;'>"."<b>Past Record: ".$pastrecord."</b></p>";
	echo "<p style='color: black; font-size: 25px;'>"."<b>Status: ".$status."</b></p>";
	
	
	
	
	echo'</div>';
}

?>