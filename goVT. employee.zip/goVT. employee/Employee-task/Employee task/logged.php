
//this sample
<?php 
session_start();
require('connect.php');
$_SESSION['pagemarker']='';
if((isset($_REQUEST['username'])) || (isset($_REQUEST['password'])))
{
	$user = $_POST['username'];
	$pass = $_POST['password'];


	//searching admin
	$sql = "SELECT * FROM `employee1` WHERE UserName = '$user'";
	$res1 = mysql_query($sql) or die(mysql_error()."admin");
	$count = mysql_num_rows($res1);

	

	if($count == 1)
	{
		$_SESSION['u_name'] = $user;
		$_SESSION['pagemarker']='employee';
		header('Location: user.php');
	}
	else
	{
		header('Location: admin.php');
	}

}

	


?>