<!DOCTYPE html>
<html >
<head>
	</head>
<body>
	<div align="right" style="margin: 20px;">
	<a href="login.php">logout</a>
	
</div>

				<ul>
					<li>
						<a href="employeeinformation.php">view information</a>
					</li>
						
					<li>
						<a href="noticeview.php">Notice</a>
					</li>
					
				</ul>
					
	

</body>
</html>
