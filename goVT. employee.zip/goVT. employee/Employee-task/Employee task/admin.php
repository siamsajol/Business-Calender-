<html>
<head>

</head>

<body>
<div align="right" style="margin: 20px;">
	<a href="login.php">logout</a>
</div>

<div align="left" style="margin: 20px;">
<li><a href="employeeentry.php">Entry Employee</a></li>
<li><a href="notice.php">Entry notice</a></li>

</div>
</body>
</html>
