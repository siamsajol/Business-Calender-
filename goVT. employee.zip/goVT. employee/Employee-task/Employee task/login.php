<html>
<title>Login</title>

<body>
<form action="logged.php" method="POST">Username: <input type="text"
	name="username" /><br></br>
Password: <input type="password" name="password" /><br></br>
<input type="submit" name="Login" /></form>

</body>