-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 22, 2015 at 10:29 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shiam`
--

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `DepartmentID` int(5) NOT NULL,
  `DepartmentName` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`DepartmentID`, `DepartmentName`) VALUES
(11101, 'Fisheries and Livest'),
(11102, 'Bangladesh Police'),
(11103, 'Bank Department'),
(11104, 'Wasa Department '),
(11105, 'RAJUK Department');

-- --------------------------------------------------------

--
-- Table structure for table `employee1`
--

CREATE TABLE IF NOT EXISTS `employee1` (
  `EmployeeID` int(10) NOT NULL,
  `UserPassword` varchar(20) DEFAULT NULL,
  `Email` varchar(20) DEFAULT NULL,
  `FirstName` varchar(40) DEFAULT NULL,
  `LastName` varchar(40) DEFAULT NULL,
  `UserName` varchar(40) DEFAULT NULL,
  `DateOfBirtth` date NOT NULL,
  `Address` varchar(40) DEFAULT NULL,
  `PhoneNo` int(11) NOT NULL,
  `Education` varchar(500) DEFAULT NULL,
  `Recruitment` date DEFAULT NULL,
  `DepartmentID` int(15) NOT NULL,
  `Transfer` varchar(500) NOT NULL,
  `StartingSalary` varchar(15) DEFAULT NULL,
  `CurrentSalary` varchar(15) DEFAULT NULL,
  `PensionMoney` varchar(12) NOT NULL,
  `PastRecord` varchar(200) DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`EmployeeID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee1`
--

INSERT INTO `employee1` (`EmployeeID`, `UserPassword`, `Email`, `FirstName`, `LastName`, `UserName`, `DateOfBirtth`, `Address`, `PhoneNo`, `Education`, `Recruitment`, `DepartmentID`, `Transfer`, `StartingSalary`, `CurrentSalary`, `PensionMoney`, `PastRecord`, `Status`) VALUES
(10101, 'abdul12', 'Ali@yahoo.com', 'Abdul', 'Alim', 'AliAbdul', '1987-09-10', 'Mirpur, Dhaka', 1672444332, 'School: Mirpur Bangla School, College: Dhaka College. University: Dhaka University', '2010-12-01', 11101, '1. Dhaka to Chittagong 2.Chittagong to Khulna.', '20,000 tk', '27,000 tk', 'Not yet.', 'No Corruption elegation', 'Current Employee'),
(10102, 'abdulahmed', 'ahmed01@yahoo.com', 'Abdul', 'Ahmed', 'AhmedAbdul', '1986-04-08', 'Dhanmondi, Dhaka', 1717116564, 'School: Dhanmondi Govt. Boys High School. College: Dhaka City College. University: Jogonnath University. ', '2010-04-01', 11102, '1. Khulna to Munshigonj. 2. Munshigonj to Feni ', '15000 tk', '25000tk', 'Not yet.', 'No Corruption elegation.', 'Current Employee'),
(10103, 'bijoymahmud', 'bijoy16dec@gmail.com', 'Bijoy', 'Mahmud', 'Mahmud_bijoy', '1991-01-01', 'Kolabagan, Dhaka', 1717778910, 'School: Sylet Zila School. College: Sylet  Govt. College', '2005-05-01', 11103, '1. Sirajgonj to Saiyoidpur 2. Saiyadpur to Pabna', '30000 tk ', '45000 tk', 'Not yet.', 'No Corruption Elegation', 'Current Employee'),
(10104, 'binabina', 'h.bina@hotmail.com', 'Bina', 'Hasan', 'Hasan_bina', '1993-01-01', 'Jattrabari, Dhaka', 1823476983, 'School: Jattrabari Ideal High School. College: Motijheel Ideal College. University: National University', '2014-04-01', 11104, '1. Dhaka to Nowakhali 2. Nowakhali to Phirojpur', '22,000tk', '29,000 tk', 'Not yet.', 'No Corruption Elegance ', 'Current Employee'),
(10105, 'rajarani', 'rani19@hotmail.com', 'Bristy', 'kabir', 'bristi_kabir', '1970-08-02', 'Motijhell, Dhaka', 1872635761, 'School: Motijhell Ideal School. College: Motijhell Ideal College\r\nUniversity: Dhaka University', '1994-08-01', 11105, '1. Dhaka to Munshigonj 2. Munshigonj to Feni. 3. Feni to Khulna', '12,000tk', 'Retire', '10,000 tk', 'No Corruption Elegance.', 'Retired '),
(10106, 'sarkar2020', 'sarkar@yahoo.com', 'Bithi ', 'Sarkar', 'BithiNithi', '2068-01-08', 'Kalitola,Dinajpur ', 1923875641, 'School: Dinajpur Zila School. College: DInajpur Govt. Girls College. University: Chittagong University', '1992-01-01', 11101, '1. Sylet to Hobigonj. 2. Hobigonj to Rongpur 3. Rongpur to Dhaka', '8,000 tk', 'No', '12,000 tk', 'No Corruption Elegation', 'Retired '),
(10107, 'lightlost', 'depokun@yahoo.com', 'Depok', 'Bishwash', 'BishwashDepok', '1989-04-24', 'Louhojonj, Munshigonj ', 1983762453, 'School: Munshijonj Zila School. College: Sreenagar College. University: Dhaka University', '2013-01-01', 11101, 'No Transfer', '23,000tk', '23,000tk', 'Not yet.', 'No Corruption Elegance ', 'Current Employee'),
(10108, '10108012DINA', 'dinaali@yahoo.com', 'Dina', 'Ali', 'ali_dina', '1981-09-02', 'Uttara, Dhaka', 1717666789, 'School: Uttara High School. College: Uttara Girls College. University: National University', '2004-01-01', 11101, 'No Transfer.', '12,000 tk', '18,000tk', 'Not yet.', 'She was suspended for 2 months for taking bribr', 'Current Employee'),
(10109, 'esahafiz', 'hafizesa@gmail.com', 'Esa', 'Hafiz', 'esa.hafiz', '1975-09-05', 'Tikatoli, Dhaka', 1678679898, 'School: Kamrunnesa Govt. Girls School. College: Motijheel Ideal College. University: National University', '1999-07-01', 11104, '', '11,000tk', '25,000tk', 'Not yet', 'No Corruption Elegance', 'Current Employee'),
(10110, 'khan2khan', 'khan2n@gmail.com', 'Emon', 'Khan', 'khan_emon', '1965-02-22', 'Ajimpur, Dhaka', 1987876871, 'School: University Labratory School and College. College: University Labratory School and College.University: Dhaka University', '1988-04-01', 11105, '1. Maymansing to Pabna. 2. Pabna to Dhamrai. 3. Dhamrai to Barishal. 4. Barishal to Tangail ', '6,000 tk', 'no', '15,000tk', 'He was suspended for six month for taking bribe', 'Retired ');

-- --------------------------------------------------------

--
-- Table structure for table `employeenotice`
--

CREATE TABLE IF NOT EXISTS `employeenotice` (
  `EmployId` int(40) DEFAULT NULL,
  `Notice` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employeenotice`
--

INSERT INTO `employeenotice` (`EmployId`, `Notice`) VALUES
(12101032, 'good');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `Name` text NOT NULL,
  `Id` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
