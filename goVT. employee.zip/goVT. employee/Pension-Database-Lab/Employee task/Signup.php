<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="style.css">
	<title>HTML</title>
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,400,300,700,600' rel='stylesheet' type='text/css'>
</head>
<body>
	<div class="header-area">	
		<div class="container clear">
		
			<div class="logo">	
				<a href="#"></a>

			</div>
			<div class="social-icons">
				<ul class="contact-info clear">
					<li><span class="email"></span>Istansau@yahoo.com</a></li>
					<li><span class="phone"></span>+8801681411568</li>
				</ul>
				<ul class="social-links clear">
					<li class="facebook"><a href="https://www.facebook.com/tanvir.pele"></a></li>
					<li class="twitter"><a href="#">twitter</a></li>
					<li class="linked-in"><a href="#">linked In</a></li>
					<li class="pinterest"><a href="#">Pinterest</a></li>
					<li class="stumbleupon"><a href="#">stumbleupon</a></li>
					<li class="times"><a href="#">times</a></li>
					<li class="fox"><a href="#">Pinterest</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="menu-area">
		
		<div class="container">
			<div class="mainmenu">
				<ul class="nav clear">
				<li>
						<a href="home.php">HOME</a>
					</li>
					<li>
						<a href="login.php">LOGIN</a>
					
					<li>
						<a href="Signup.php">SIGNUP</a>
					</li>
					
				</ul>
			</div>
		</div>
	</div>	    
                              
            
        

<h1>Employee Registration</h1>
<div align="center">
<br></br>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<table >

<tr>
<td width="100" height="40">EmployeeID:</td>
<td ><input type="text" name="eid" placeholder="give Employe id"/></td>
</tr>

<tr>
<td width="100" height="40">UserPassword: </td>
<td><input type="text" name="upass" placeholder="password"/></td>
</tr>


<tr>
<td width="100" height="40">Email: </td>
<td><input type="text" name="email" placeholder="email"/></td>
</tr>

<tr>
<td width="100" height="40">Firstname: </td>
<td><input type="text" name="fname"  placeholder="give first name"/></td>
</tr>

<tr>
<td width="100" height="40">Lastname: </td>
<td><input type="text" name="lname" placeholder="give last name"/></td>
</tr>

<tr>
<td width="100" height="40">User name: </td>
<td><input type="text" name="uname" placeholder="user name"/></td>
</tr>

<tr>
<td width="100" height="40">Date of Birth: </td>
<td><input type="text" name="dob" placeholder="yyyy/mm/dd"/></td>
</tr>

<tr>
<td width="100" height="40">Address: </td>
<td><input type="text" name="addrs" placeholder="give address"/></td>
</tr>


<tr>
<td width="100" height="40">PhoneNo: </td>
<td><input type="text" name="phn" placeholder="give phone no"/></td>
</tr>
<tr>
<td width="100" height="40">Education </td>
<td><input type="text" name="ed" placeholder="give Education status"/></td>
</tr>
<tr>
<td width="100" height="40">DepartmentId: </td>
<td><input type="text" name="drt" placeholder="give Department Id"/></td>
</tr>
<tr>
<td width="100" height="40">Status: </td>
<td><input type="text" name="stas" placeholder="status for this employee"/></td>
</tr>
<tr>
<td width="100" height="40"><input type="submit" name ="registration" value="Register"></td></table>
</tr>
</form>

</div>
</div>
<br></br>


</body>
</html>
<?php
include("connect.php");

if(isset($_POST['registration']))
{
	
	 
	$sql = "INSERT INTO  employee1(EmployeeID,UserPassword,Email,FirstName,LastName,UserName,DateOfBirtth,Address
	,PhoneNo,Education,Recruitment,DepartmentID,Transfer,StartingSalary,CurrentSalary,PensionMoney,PastRecord,Status)
	 Values
	($_POST[eid],'$_POST[upass]','$_POST[email]','$_POST[fname]','$_POST[lname]','$_POST[uname]','$_POST[dob]',
	'$_POST[addrs]',$_POST[phn],'$_POST[ed]','$_POST[rct]',$_POST[drt],'$_POST[trs]',
	'$_POST[sts]','$_POST[cts]','$_POST[pmn]','$_POST[prs]','$_POST[stas]')";
	
if(!mysql_query($sql))
	{
		//echo("go");
		die('Errorshow:  '.mysql_error());
	}else{
		//echo("successfully inserted");
		echo'<script type="text/javascript">';
        echo'alert ("successfully inserted");';
       echo"</script>"; 

      }
      
}


?>