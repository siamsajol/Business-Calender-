<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="style.css">
	<title>HTML</title>
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,400,300,700,600' rel='stylesheet' type='text/css'>
</head>
<body>
	<div class="header-area">	
		<div class="container clear">
		
			<div class="logo">	
				<a href="#"></a>

			</div>
			<div class="social-icons">
				<ul class="contact-info clear">
					<li><span class="email"></span>Istansau@yahoo.com</a></li>
					<li><span class="phone"></span>+8801681411568</li>
				</ul>
				<ul class="social-links clear">
					<li class="facebook"><a href="https://www.facebook.com/tanvir.pele"></a></li>
					<li class="twitter"><a href="#">twitter</a></li>
					<li class="linked-in"><a href="#">linked In</a></li>
					<li class="pinterest"><a href="#">Pinterest</a></li>
					<li class="stumbleupon"><a href="#">stumbleupon</a></li>
					<li class="times"><a href="#">times</a></li>
					<li class="fox"><a href="#">Pinterest</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="menu-area">
		<div class="container">
			<div class="mainmenu">
				<ul class="nav clear">
				<li>
						<a href="home.php">HOME</a>
					</li>
					<li>
						<a href="login.php">LOGIN</a>
					
					<li>
						<a href="Signup.php">SIGNUP</a>
					</li>
					<li>
						<a href="admin.php">ADMIN</a>
					</li>
					<li>
						<a href="employeeinformation.php">Employee Account</a>
					</li>
					
					
				</ul>
			</div>
		</div>
	</div>
	<div class="slider-area">
		<div class="container clear">
			<div class="slider">
				<img src="img/slider.jpg">
			</div>
			<div class="slider-text">
				<h1 class="slider-bg"> Welcome To</h1>

				<h2>Pension Database </h2> 

				<p>And Career Summary</p>
			</div>
		</div>
	</div>
	<div class="call-to-action-area">
		<div class="container clear">
			<div class="call-to-action clear">
				<h3>The Government of Bangladesh is proud to offer you this Web portal where you'll find valuable information, tools and services regarding your public service pension plan .
				<h4></h4>
				<a href=""class="button">Learn More</a>
			
			</div>
		</div>
	</div>
	
	<div class="testimonial-area">
		<div class="container clear">
			<div class="testimonial">
				<h2>Quote of the day</h2>
			</div>
			<div class="client-comments clear">
				<blockquote class="invated_icon"><img src="img/invated_icon.jpg" style="margin-right: 11px;">“Retire from work, but not from life.” 
				</blockquote>	
			</div>
			<div class="client clear">
				<img src="img/man_icon.png"/>
				<a href=""><h4>―<p> M. K. Soni</p></h4></a>
				
			</div>
		</div>
	</div>
	<div class="featured-case-studies-area">
		<div class="container clear">
			<div class="case-studies">
				<h2>Recent News Feed</h2>
			</div>
			<div class="">
				<div class="single-case-studies">
					<div class="case-studies-thumbnail">
						<img src="img/case_studies1.jpg" style="border: 7px solid #fff;"/>
					</div>
					<h3><font color="red">Active Members</font> </h3>
					
					<p>Everything you need to know about your pension scheme</p>
					<a href="" class="keep-reading">Keep Reading<img src="img/keep_read_icon.png" style="margin-left: 7px;"/></a>
					
				</div>
				<div class="single-case-studies">
					<div class="case-studies-thumbnail">
						<img src="img/case_studies2.jpg" style="border: 7px solid #fff;"/>
					</div>
					<h3><font color="">Planning for retirement</font> </h3>
				
					<p>Learn about the flexible options available within your pension.</p>
					<a href="" class="keep-reading">Keep Reading<img src="img/keep_read_icon.png" style="margin-left: 7px;"/></a>
					
				</div>
				<div class="single-case-studies">
					<div class="case-studies-thumbnail">
						<img src="img/case_studies3.jpg" style="border: 7px solid #fff;"/>
					</div>
					<h3><font color="red">Starting Out</font> </h3>
					
					<p>Information to help you start making the most of your pension.

</p>
					<a href="" class="keep-reading">Keep Reading<img src="img/keep_read_icon.png" style="margin-left: 7px;"/></a>
					
				</div>
				<div class="single-case-studies">
					<div class="case-studies-thumbnail">
						<img src="img/case_studies4.jpg" style="border: 7px solid #fff;"/>
					</div>
					<h3><font color="red">Managing your pension in retirement</font> </h3>
					
					<p>Find out about your current benefits and how to manage them.

</p>
					<a href="" class="keep-reading">Keep Reading<img src="img/keep_read_icon.png" style="margin-left: 7px;"/></a>
					
				</div>
			</div>
		</div>
	</div>
	<div class="footer-widget-area">
		<div class="container clear">
			<div class="single-services clear">
				<h3>Contact Us</h3>
				<p>Mirpur Dhaka</p>
				<p>Mail Id-Sauravtanvir@yahoo.com</p>
				</br>
				
			</div>
			<div class="single-services clear">
				
				<h3>Forgot your PIN or Password?</h3>
				<div class="login-info">
					<form class="form" action="submit.html" method="post">

					<input class="name" type="text" name="name" id="name" placeholder="Name" required="required"/><br/>

					<input class="email-id" type="text" name="email" id="email" placeholder="Email address" required="required"/><br/>
					</form></br>
					<a href=""class="button">Help</a>
				</div>
				
				</div>
			</div>
		</div>
	</div>
	<div class="footer-menu-area">
		<div class="container clear">
			<div class="copy-right clear">
				<p>&copy;2015 All Rights reserved by ISLAM TANVIR</p>
			</div>
			<div class="footer-menu clear">
				<ul>
					<li><a href="">Home</a></li>
					<li><a href="">Services</a></li>
					<li><a href="">Portfolio</a></li>
					<li><a href="">About Us</a></li>
					<li><a href="">Our Blog</a></li>
					<li><a href="">Contact Us</a></li>
				</ul>
			</div>
		</div>
	</div>
</body>
</html>