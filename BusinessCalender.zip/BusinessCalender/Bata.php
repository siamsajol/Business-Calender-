<?php
   include('connect.php');
   session_start();
   error_reporting(0);
   //$user_check = $_SESSION['login_user'];

  $user= $_SESSION['u_name'];
      
   if(!isset($_SESSION['u_name'])){
      header("location:Login.php");
   }
?>
<!DOCTYPE html>

<html class="no-js"> 
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Business Calender</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
		
      <link rel="stylesheet" href="css/font-awesome.min.css"/>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
        <link rel="stylesheet" href="css/main.css"/>


        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,400,300,600,700' rel='stylesheet' type='text/css'>
    </head>
    <body>
    
		
					<div class="col-lg-6">
					   <div id="custom-search-input">
                            <div class="input-group">
                                
                                <span class="input-group-btn">
                                   
                                        <span><i class="fa fa-search"></i></span>
                                    </button>
                                </span>
                            </div>
                        </div>
					</div>
					<div class="col-lg-5">
						<div class="pull-right user_menu">
							<ul class="nav navbar-nav">
								<li><a href="404.html"><i class="fa fa-user"></i> My Account</a></li>
								<li><a href="login.php"><i class="fa fa-sign-in"></i> Login</a></li>
                                <li><a href="logout.php"><i class="fa fa-sign-in"></i> Logout</a></li>
								<li><a href="signup.php"><i class="fa fa-sign-out"></i> Sign Up</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- end header middle section -->

        <div class="header_bottom_area">
        	<div class="container">
        		<div class="row">
        			<div class="col-lg-6">
        				<div class="nav-menu nav-pills pull-left mainmenu">
        					<ul class="nav navbar-nav">
								<li><a href="index.php">HOME</a></li>
								<li><a href="404.html">ABOUT</a></li>
								<li><a href="404.html">CONTACT</a></li>
								<li><a href="404.html">BLOG</a></li>
								<li><a href="404.html"></a></li>        
							</ul>
        				</div>
        			</div>
        			<div class="col-lg-6">
        				<div class="shop-menu pull-right mainmenu">
							<ul class="nav navbar-nav">
								<li><a href="404.html"><i class="fa fa-star"></i> Wishlist</a></li>
								<li><a href="checkout.html"><i class="fa fa-crosshairs"></i> Checkout</a></li>
								<li><a href="calendar.php"><i class="fa fa-shopping-cart"></i> Calendar</a></li>
							</ul>
						</div>
        			</div>
        		</div>
        	</div>
        </div>

     

        <div class="main_slider_area">
        	<div class="container">
        		<div class="row">
        			<div class="col-lg-8">
        				<div class="slider_area">
							<div id="carousel-example-generic" class="carousel slide" data-ride ="carousel" ><!-- Indicators -->
								<ol class="carousel-indicators">
								   <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
								    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
								    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
								    <li data-target="#carousel-example-generic" data-slide-to="3"></li>
								    <li data-target="#carousel-example-generic" data-slide-to="4"></li>
								</ol> <!-- Wrapper for slides -->
						  	
						</div>
        			</div>

        			<!-- end left slider section -->

        			
        		</div>
        	</div>
        </div>

        <!-- end slider section -->

        <div class="main_content_area">
        	<div class="container">
        		<div class="row">
        		 	<div class="col-sm-3">
						<div class="left-sidebar">
							<h2 class="text-uppercase text-center">All Category</h2>
							<div class="panel-group category_products" id="accordian">

					<div class="panel panel-default">
									<div class="panel-heading">
										<h4 class="panel-title"><a href="apple.php">apple Products</a></h4>
									</div>
								</div>

								<div class="panel panel-default">
									<div class="panel-heading">
										<h4 class="panel-title">

											<a data-toggle="collapse" data-parent="#accordian" href="#Mobile_Phones"><span class="pull-right"><i class="fa fa-chevron-down"></i></span>Mobile Phones</a>
										</h4>
									</div>
									<div id="Mobile_Phones" class="panel-collapse collapse">
										<div class="panel-body">
											<ul>
												<li><a href="#">Smartphones</a></li>
												<li><a href="#">Feature Phones</a></li>
												<li><a href="#">Samsung Accessories</a></li>
												<li><a href="#">Earphones & Speakers</a></li>
												<li><a href="#">Memory Cards</a></li>
												<li><a href="#">Smart Devices</a></li>
												<li><a href="#">Repair Tools</a></li>
											</ul>
										</div>
									</div>
								</div>


								<div class="panel panel-default">
									<div class="panel-heading">
										<h4 class="panel-title"><a href="#">Health & Beauty</a></h4>
									</div>
								</div>
								<div class="panel panel-default">
									<div class="panel-heading">
										<h4 class="panel-title"><a href="#">Home and Garden</a></h4>
									</div>
								</div>
								<div class="panel panel-default">
									<div class="panel-heading">
										<h4 class="panel-title"><a href="computer.php">Computer & Networking</a></h4>
									</div>
								</div>
								<div class="panel panel-default">
									<div class="panel-heading">
										<h4 class="panel-title"><a href="#">Jewelry and Watch</a></h4>
									</div>
								</div>
								<div class="panel panel-default">
									<div class="panel-heading">
										<h4 class="panel-title"><a href="#">Automobiles & Motorcycles</a></h4>
									</div>
								</div>
								<div class="panel panel-default">
									<div class="panel-heading">
										<h4 class="panel-title"><a href="#">Electronics</a></h4>
									</div>
								</div>
								<div class="panel panel-default">
									<div class="panel-heading">
										<h4 class="panel-title"><a href="#">Lights & Lighting</a></h4>
									</div>
								</div>
							</div>
						</div>
					</div>

					

					<div class="col-lg-9 padding-right">
						<div class="features_items">
							<h2 class="text-uppercase text-center">Discount items</h2>
							<div class="col-lg-4">
								<div class="product-image-wrapper">
									<div class="single-products">
										<div class="productinfo">
											<img src="img/BASTO-Basto-sheepskin- (1).jpg" alt=""/>
											<p><a href="product-details.html">BASTO-Basto-sheepskin</a></p>
											<h4 class="text-center">TK.7000.00 <span class="old_price"><s>TK.8000.00</s></span></h4>
										</div>

										<div class="choose text-center">
											<ul class="nav-pills nav-justified">
												<li><a href="#" class="btn btn-default"><i class="fa fa-plus-square"></i> Add to wishlist</a></li>
												<li><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
											</ul>
										</div>
									</div>
								</div>
							</div>

							<div class="col-lg-4">
								<div class="product-image-wrapper">
									<div class="single-products">
										<div class="productinfo">
											<img src="img/BASTO-Basto-sheepskin- (1).jpg" alt=""/>
											<p><a href="product-details.html">BASTO-Basto-sheepskin</a></p>
											<h4 class="text-center">TK.4000.00 <span class="old_price"><s>TK. 3500.00</s></span></h4>
										</div>

										<div class="choose text-center">
											<ul class="nav-pills nav-justified">
												<li><a href="#" class="btn btn-default"><i class="fa fa-plus-square"></i> Add to wishlist</a></li>
												<li><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
											</ul>
										</div>
									</div><!--/single-product-->
								</div><!--/single-product wrapper-->
							</div>
							<div class="col-lg-4">
								<div class="product-image-wrapper">
									<div class="single-products">
										<div class="productinfo">
											<img src="img/BASTO-Basto-sheepskin- (2).jpg" alt=""/>
											<p><a href="">BASTO-Basto-sheepskin</a></p>
											<h4 class="text-center">TK. 4700.00 </h4>
										</div>

										<div class="choose text-center">
											<ul class="nav-pills nav-justified">
												<li><a href="#" class="btn btn-default"><i class="fa fa-plus-square"></i> Add to wishlist</a></li>
												<li><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
											</ul>
										</div>
									</div><!--/single-product-->
								</div><!--/single-product wrapper-->
							</div>
							<div class="col-lg-4">
								<div class="product-image-wrapper">
									<div class="single-products">
										<div class="productinfo">
											<img src="img/BASTO-Basto-sheepskin- (3).jpg" alt=""/>
											<p><a href="">BASTO-Basto-sheepskin</a></p>
											<h4 class="text-center">TK 1100.00 <span class="old_price"><s>TK 1300.00</s></span></h4>
										</div>

										<div class="choose text-center">
											<ul class="nav-pills nav-justified">
												<li><a href="#" class="btn btn-default"><i class="fa fa-plus-square"></i> Add to wishlist</a></li>
												<li><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
											</ul>
										</div>
									</div><!--/single-product-->
								</div><!--/single-product wrapper-->
							</div>
							<div class="col-lg-4">
								<div class="product-image-wrapper">
									<div class="single-products">
										<div class="productinfo">
											<img src="img/BASTO-Basto-sheepskin- (4).jpg" alt=""/>
											<p><a href="">BASTO-Basto-sheepskin- (4)</a></p>
											<h4 class="text-center">TK.8000.00</h4>
										</div>

										<div class="choose text-center">
											<ul class="nav-pills nav-justified">
												<li><a href="#" class="btn btn-default"><i class="fa fa-plus-square"></i> Add to wishlist</a></li>
												<li><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
											</ul>
										</div>
									</div><!--/single-product-->
								</div><!--/single-product wrapper-->
							</div>
							<div class="col-lg-4">
								<div class="product-image-wrapper">
									<div class="single-products">
										<div class="productinfo">
											<img src="img/BASTO-Basto-sheepskin- (5).jpg" alt=""/>
											<p><a href="">BASTO-Basto-sheepskin- (5)</a></p>
											<h4 class="text-center">TK.11000.00 <span class="old_price"><s>TK.10000.00</s></span></h4>
										</div>

										<div class="choose text-center">
											<ul class="nav-pills nav-justified">
												<li><a href="#" class="btn btn-default"><i class="fa fa-plus-square"></i> Add to wishlist</a></li>
												<li><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
											</ul>
										</div>
									</div><!--/single-product-->
								</div><!--/single-product wrapper-->
							</div>
						</div><!--/features_items-->

						<!--latest products pagination-->
						<nav>
							 <ul class="pagination pull-right">
							    <li class="disabled"><a href="#"><span aria-hidden="true">&laquo;</span><span class="sr-only">Previous</span></a></li>
							    <li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
							    <li><a href="#">1 <span class="sr-only">(current)</span></a></li>
							    <li><a href="#">2 <span class="sr-only">(current)</span></a></li>
							    <li><a href="#">3 <span class="sr-only">(current)</span></a></li>
							    <li><a href="#">4 <span class="sr-only">(current)</span></a></li>
							    <li><a href="#"><span aria-hidden="true">&raquo;</span><span class="sr-only">Next</span></a></li>
							 </ul>
						</nav>


						<!---tab_category-->


						<div class="tab_category">
							<div class="col-sm-12 category_tab">
								<ul class="nav nav-tabs text-uppercase">
									<li><a href="#tshirt" data-toggle="tab">T-Shirt</a></li>
									<li><a href="#mens" data-toggle="tab">Mens</a></li>
									<li><a href="#womens" data-toggle="tab">Womens</a></li>
									<li><a href="#kids" data-toggle="tab">Kids</a></li>
									<li><a href="#pant" data-toggle="tab">Pants</a></li>
								</ul>
							</div>
							<div class="tab-content">
								<div class="tab-pane fade active in" id="tshirt" >
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab1.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">TK. 199.00 <span class="old_price"><s>TK. 230.00</s></span></h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab2.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">TK. 299.00</h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab3.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">TK. 199.00 <span class="old_price"><s>TK. 230.00</s></span></h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab4.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">TK.199.00 <span class="old_price"><s>TK. 230.00</s></span></h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
								</div>
								
								<div class="tab-pane fade" id="mens" >
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab4.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">TK. 400.00</h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab3.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">TK. 199.00 <span class="old_price"><s>TK. 230.00</s></span></h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab2.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">TK. 199.00 <span class="old_price"><s>TK.230.00</s></span></h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab1.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">TK.199.00 <span class="old_price"><s>TK.230.00</s></span></h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
								</div>
								
								<div class="tab-pane fade" id="womens" >
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab4.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">TK.200.00</h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab5.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">TK.199.00 <span class="old_price"><s>TK.230.00</s></span></h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab2.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">US$199.00 <span class="old_price"><s>US$230.00</s></span></h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab3.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">US$199.00 <span class="old_price"><s>US$230.00</s></span></h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
								</div>
								
								<div class="tab-pane fade" id="kids" >
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab5.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">US$199.00 <span class="old_price"><s>US$230.00</s></span></h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab4.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">US$199.00 <span class="old_price"><s>US$230.00</s></span></h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab1.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">US$199.00 <span class="old_price"><s>US$230.00</s></span></h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab2.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">US$199.00 <span class="old_price"><s>US$230.00</s></span></h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
								</div>
								
								<div class="tab-pane fade" id="pant" >
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab5.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">US$199.00 <span class="old_price"><s>US$230.00</s></span></h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab2.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">US$199.00 <span class="old_price"><s>US$230.00</s></span></h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab4.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">US$199.00 <span class="old_price"><s>US$230.00</s></span></h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
									<div class="col-sm-3">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo">
													<img src="img/tab1.jpg" alt=""/>
													<p><a href="">Mini Waterproof Wireless</a></p>
													<h4 class="text-center">TK.300.00</h4>
												</div>

												<div class="choose text-center">
													<ul class="nav-pills nav-justified">
														<li class="text-center"><a href="#" class="btn btn-default"><i class="fa fa-shopping-cart"></i> Add to cart</a></li>
													</ul>
												</div>
											</div><!--/single-product-->
										</div>
									</div>
								</div>
							</div>
						</div><!--/category-tab-->
					</div>
				</div><!-- /row-->
        	</div><!-- /container-->
        </div><!-- /main_content-->

        <div class="payment_getway_area">
        	<div class="container">
        		<div class="row">
        			<div class="col-lg-12">
        				
        		</div>
        	</div>
        </div>

        <!-- footer area-->

        <div class="footer_area">
        	<div class="footer_top"><!-- footer top-->
        	
						</div>
					</div>
        		</div>
        	</div><!-- /footer top-->

        	<div class="footer-middle"><!-- footer middle-->
				<div class="container">
					<div class="row">
						<div class="col-lg-3">
							<div class="single_info">
								<h3 class="text-uppercase">Our Services</h3>
								<ul class="nav nav-pills nav-stacked">
									<li><a href="#">Online Help</a></li>
									<li><a href="#">Contact Us</a></li>
									<li><a href="#">Order Status</a></li>
									<li><a href="#">Change Location</a></li>
									<li><a href="#">FAQ’s</a></li>
								</ul>
							</div>
						</div>
						<div class="col-lg-3">
							<div class="single_info">
								<h3 class="text-uppercase">Terms & Policy</h3>
								<ul class="nav nav-pills nav-stacked">
									<li><a href="#">Terms of Use</a></li>
									<li><a href="#">Privecy Policy</a></li>
									<li><a href="#">Refund Policy</a></li>
									<li><a href="#">Billing System</a></li>
									<li><a href="#">Ticket System</a></li>
								</ul>
							</div>
						</div>
						<div class="col-lg-3">
							<div class="single_info">
								<h3 class="text-uppercase">About Business Calendar</h3>
								<ul class="nav nav-pills nav-stacked">
									<li><a href="#">Company Information</a></li>
									<li><a href="#">Careers</a></li>
									<li><a href="#">Store Location</a></li>
									<li><a href="#">Affillate Program</a></li>
									<li><a href="#">Copyright</a></li>
								</ul>
							</div>
						
				</div>
			</div><!-- /footer middle-->
        </div>


     

        <script src="js/jquery-2.1.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/main.js"></script>
    </body>
</html>
