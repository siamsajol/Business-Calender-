-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2017 at 09:40 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `businesscalender`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE IF NOT EXISTS `admin_login` (
  `user_id` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`user_id`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=Active, 0=Block',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `date`, `created`, `modified`, `status`) VALUES
(1, 'haha', '2016-07-21', '2016-07-21 05:27:59', '2016-07-21 05:27:59', 1),
(2, 'Test Event', '2016-07-21', '2016-07-21 06:06:17', '2016-07-21 06:06:17', 1),
(8, 'Hello World!', '2016-07-21', '2016-07-21 06:06:51', '2016-07-21 06:06:51', 1);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `username` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `mobile` varchar(25) NOT NULL,
  `dob` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`username`, `user_id`, `password`, `mobile`, `dob`) VALUES
('Anu', 'anu@anu.com', 'anu123', '123', '12-12-2017'),
('Sheldon Copper', 'coper@coper.com', '911', '911', '1-1-1989'),
('ABC', '123', '12345678', '321', '1-1-1989'),
('Kia', '101010', '1010', '1111', '1-1-1989'),
('ss', 'ss', 'aa', '11', '1-1-1989'),
('Leonard', 'leonard@leonard.com', 'leonard911', '911', '1-1-1989'),
('Coke Studio', 'coke@studio.com', 'cokestudio', '0987', '10-01-1999');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE IF NOT EXISTS `user_login` (
  `id` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`id`, `password`) VALUES
('abc@xyz.com', 'abcxyz123'),
('pqr@xyz.com', 'pqrxyz123'),
('0', '0'),
('123', '12345678'),
('abc@xyz.com', 'abcxyz123'),
('pqr@xyz.com', 'pqrxyz123'),
('101010', '1010'),
('anu@anu.com', 'anu123'),
('coper@coper.com', '911'),
('123', '12345678'),
('101010', '1010'),
('ss', 'aa'),
('anu@anu.com', 'anu123'),
('coper@coper.com', '911'),
('123', '12345678'),
('101010', '1010'),
('ss', 'aa'),
('leonard@leonard.com', 'leonard911'),
('anu@anu.com', 'anu123'),
('coper@coper.com', '911'),
('123', '12345678'),
('101010', '1010'),
('ss', 'aa'),
('leonard@leonard.com', 'leonard911'),
('coke@studio.com', 'cokestudio');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
