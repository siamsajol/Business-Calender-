<?php
session_start();
include('connect.php');
if(isset($_GET['user_id']) && isset($_GET['password'])) {
    $user_id = intval($_GET['user_id']);
    $password= intval($_GET['password']);
    $query="INSERT INTO user_login (`id`,`password`)
    SELECT user_id, password FROM registration";
    // $query="SELECT * from studentacademicinformation";
    $result = $dbLink->query($query);

    if($result) {
        echo ("<SCRIPT LANGUAGE='JavaScript'>
    		window.alert('ID is approved')
    		window.location.href='request_process.php';
    		</SCRIPT>");
        @mysqli_free_result($result);
    }
    else {
        echo "Error! Query failed: <pre>{$dbLink->error}</pre>";
    }
    @mysqli_close($dbLink);
}
else{
    echo 'Error! SQL query failed:';
        echo "<pre>{$dbLink->error}</pre>";
}

?>