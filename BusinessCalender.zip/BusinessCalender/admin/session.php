<?php
   include('connect.php');
   session_start();
   error_reporting(0);
   //$user_check = $_SESSION['login_user'];

  $user= $_SESSION['u_name'];
      
   if(!isset($_SESSION['u_name'])){
      header("location:Login.php");
   }
?>