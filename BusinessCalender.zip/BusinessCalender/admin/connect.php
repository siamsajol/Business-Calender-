<?php
$dbLink  = new mysqli("localhost", "root", "", "businesscalender");
/*// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }*/


  // Check connection
if ($dbLink->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
