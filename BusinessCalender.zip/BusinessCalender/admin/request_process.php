<?php
session_start();
include('connect.php');
?>
<style type="text/css">
table {
padding: 2px;
}

tr {
font-family: Arial, Helvetica, sans-serif;
font-size: 16px;
background: #39F;
color: #FFF;
padding: 0px 0px;
border-collapse: separate;
border: 2px solid #9F0;
}

td {
font-family: Arial, Helvetica, sans-serif;
font-size: 16px;
border: 1px solid #9F0;
text-align:center;
padding:4px 0px;

}	
</style>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
    <title>Admin page</title>
    <link href="css/style.css" rel="stylesheet" type="text/css"/>
</head>
<body>
<!--<script type="text/javascript">

             
        alert ("successfully login");

      </script> 
  -->
  
 <div style="margin:20px 0px;">
 
 <a style="background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:28px;
	border:3px solid #18ab29;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:17px;
	text-align:right;
	padding:10px 31px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	text-align:center;
	" href="logout.php">Log Out</a>
 
 <h1 style="background-color:#44c767;
	border:3px solid #18ab29;
	color:#ffffff;
	font-family:Arial;
	font-size:17px;
	padding:10px 31px;
	margin-bottom:10px;
	margin-top:20px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	text-align:center;">Registered Data</h1>
	
 </div>
    <?php
    include('connect.php');
    $sql = 'SELECT * FROM registration';
    $result = $dbLink->query($sql);
    
    if($result) {
        // Make sure there are some files in there
        if($result->num_rows == 0) {
            echo '<p>There are no files in the database</p>';
        }
        else {
            // Print the top of a table
            echo '<table width="100%">
            <tr>
            <td><b>User Name</b></td>
            <td><b>User ID</b></td>
            <td><b>Daye of Birth</b></td>
            <td><b>Phone NO</b></td>
			<td><b>Status</b></td>
            
            </tr>';

            $checkbox_marker=0;
            // Print each file
            while($row = $result->fetch_assoc()) {
                $checkbox_marker = $checkbox_marker+1;

                echo "
                <tr>
                <td>{$row['username']}</td>
                <td>{$row['user_id']}</td>
                <td>{$row['dob']}</td>
                <td>{$row['mobile']}</td>
                
                <td><a href='approve_request.php?user_id={$row['user_id']} & password={$row['password']}' target='_blank'>Approve</a></td>
                </td>

                
                </tr>";


            }

            // Close table
            echo '</table>';
        }

        // Free the result
        $result->free();
    }

    else
    {
        echo 'Error! SQL query failed:';
        echo "<pre>{$dbLink->error}</pre>";
    }

    ?>
<!-- </br>
    <form action='approve_request.php' method='post'> 
        <input type="submit" name="submit" Value="Submit"/> 
    </form> -->


</body>
</html>


<?php

/*<?php
if(!empty($_POST['checkbox'])) {
    foreach($_POST['checkbox'] as $check) {
            echo $check; 
    }
}*/

/*if(!empty($_POST['checkbox'])){
     foreach($_POST['checkbox'] as $report_id){
        echo "$report_id was checked! ";
     }
   }
*/

// echo $_POST[''check_list'']."";

   ?>



