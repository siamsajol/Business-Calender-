<?php
   include('connect.php');
   session_start();
   error_reporting(0);
   //$user_check = $_SESSION['login_user'];

  $user= $_SESSION['u_name'];
      
   if(!isset($_SESSION['u_name'])){
      header("location:admin_login.php");
   }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Admin</title>
</head>
<body>
	<h1 style="text-align:center; font-size:52px;">ADMIN PANEL</h1>
	<div style="float:none;
	text-align:center;
	width:100%;
	margin-top:20px;">
		<a style="background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:28px;
	border:3px solid #18ab29;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:17px;
	padding:10px 31px;
	margin:10px 10px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	text-align:center;
	" href="request_process.php">Pending Request</a>
	<a style="background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:28px;
	border:3px solid #18ab29;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:17px;
	padding:10px 31px;
	margin:10px 10px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	text-align:center;
	" href="../calendar.php">Calendar</a>
	<a style="background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:28px;
	border:3px solid #18ab29;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:17px;
	padding:10px 31px;
	margin:10px 10px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	text-align:center;
	" href="logout.php">Log Out</a>
	</div>
</body>
</html>
