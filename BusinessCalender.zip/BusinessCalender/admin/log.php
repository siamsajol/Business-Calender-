<?php
session_start();
require('connect.php');

$_SESSION['pagemarker']='';
if((isset($_REQUEST['user_id'])) || (isset($_REQUEST['password'])))
{
	$user = $_POST['user_id'];
	$pass = $_POST['password'];


	//searching admin
	$sql = "SELECT * FROM `admin_login` WHERE user_id = ? AND password= ?";
	$stmt = $dbLink->prepare($sql);
	$stmt->bind_param("is",$user,$pass);
	$stmt->execute();
	
	/* store result */
    $stmt->store_result();
	$count = $stmt->num_rows;
    //printf("Number of rows: %d.\n", $stmt->num_rows);
	

	if($count == 1)
	{
		$_SESSION['u_name'] = $user;
		$_SESSION['pagemarker']='admin_login';
		//$_SESSION['password'] = $pass;
		// header('Location: admin.php');
		//echo 'alert ("ok")';
		header('Location: admin_index.php');
		
	}
	else
	{
		echo '<script type="text/javascript">';
		echo 'alert ("Wrong User name or password.")';
		echo '</script>';
		header("location:admin_login.php");
	}

}





?>
