<!DOCTYPE html>
<?php
session_start();
require('connect.php');

?>
<html >
  <head>
    <meta charset="UTF-8">
    <title>ADMIN LOGIN</title>
    
        <link rel="stylesheet" href="css/style.css">

  </head>

  <body>

    <div class="login-page">
  <div class="form">
      <form action="log.php" method = "POST" class="login-form">
		  <input type="text" name="user_id" placeholder="admin id"/>
		  <input type="password" name="password" placeholder="password"/>
		  <button type="submit">login</button>
      </form>
	  <form action="../login.php">
      	  <button style="margin:15px 0px;" type="submit">User Login</button>
	  </form>
  </div>
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script src="js/index.js"></script>

    
    
    
  </body>
</html>
