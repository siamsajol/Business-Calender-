<?php
$username=$_POST['username'];
$user_id=$_POST['user_id'];
$password=$_POST['password'];
$mobile=$_POST['mobile'];
$dob=$_POST['dob'];

include("connect.php");
$query="INSERT INTO registration (`username`,`user_id`,`password`,`mobile`, `dob`)
	VALUES ('$username','$user_id','$password','$mobile','$dob')" ;
	$result = $dbLink->query($query);
if($result)
{
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    		window.alert('Your request is being processed.')
    		window.location.href='signup.php';
    		</SCRIPT>");
	
}else
{
echo 'Error! Failed to insert the file'
                   . "<pre>{$dbLink->error}</pre>";
}
?>

