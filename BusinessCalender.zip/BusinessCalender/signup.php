<html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>CheckOut | Business Calender</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
		
        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	
		<link rel="stylesheet" href="css/font-awesome.min.css"/>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
        <link rel="stylesheet" href="css/main.css"/>


        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,400,300,600,700' rel='stylesheet' type='text/css'>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <!-- Add your site or application content here -->

		<!-- end header top section -->

		<div class="header_middle_area">
			<div class="container">
				<div class="rwo middle_row">
					<div class="col-lg-2">
						
					</div>
					<div class="col-lg-6">
					   <div id="custom-search-input">
                           
                                <span class="input-group-btn">
                                    
                                        <span><i class="fa fa-search"></i></span>
                                    </button>
                                </span>
                            </div>
                        </div>
					</div>
					<div class="header_bottom_area">
        	<div class="container">
        		<div class="row">
        			<div class="col-lg-6">
        				<div class="nav-menu nav-pills pull-left mainmenu">
        					<ul class="nav navbar-nav">
								<li><a href="index.php">HOME</a></li>
								<li><a href="404.html">ABOUT</a></li>
								<li><a href="404.html">CONTACT</a></li>
								<li><a href="404.html">BLOG</a></li>
								<li><a href="404.html"></a></li>        
							</ul>
        				</div>
        			</div>
					<div class="col-lg-5">
						<div class="shop-menu pull-right mainmenu">
							<ul class="nav navbar-nav">
								<li><a href="#"><i class="fa fa-star"></i> Wishlist</a></li>
								<li><a href="checkout.html"><i class="fa fa-crosshairs"></i> Checkout</a></li>
								<li><a href="cart.html"><i class="fa fa-shopping-cart"></i> My Cart</a></li>
								<li><a href="login.php"><i class="fa fa-shopping-cart"></i> Login</a></li>
								<li><a href="admin/admin_login.php"><i class="fa fa-shopping-cart"></i> Admin Login</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
		    <div class="omb_login">
		    	<h3 class="omb_authTitle">Login or <a href="#">Sign up</a></h3>
				<div class="row omb_row-sm-offset-3 omb_socialButtons">
		    	    <div class="col-xs-4 col-sm-2">
				        <a href="#" class="btn btn-lg btn-block omb_btn-facebook">
					        <i class="fa fa-facebook visible-xs"></i>
					        <span class="hidden-xs">Facebook</span>
				        </a>
			        </div>
		        	<div class="col-xs-4 col-sm-2">
				        <a href="#" class="btn btn-lg btn-block omb_btn-twitter">
					        <i class="fa fa-twitter visible-xs"></i>
					        <span class="hidden-xs">Twitter</span>
				        </a>
			        </div>	
		        	<div class="col-xs-4 col-sm-2">
				        <a href="#" class="btn btn-lg btn-block omb_btn-google">
					        <i class="fa fa-google-plus visible-xs"></i>
					        <span class="hidden-xs">Google+</span>
				        </a>
			        </div>	
				</div>

		<div class="signup">
		<div class="login-info">
			<form class="form" action="submit-form.php" method="post">
				<ul>

				<li>

				<input class="name" type="text" name="username" id="name" placeholder="Name" required/>
			</li>
			<li>

				<input class="email-id" type="text" name="user_id" id="email" placeholder="Email ID" required/>
			</li>
			<li>

				<input class="phonenumber" type="phonenumber" name="mobile" id="num" placeholder="Phone Number" required/>
			</li>
			<li>

				<input class="datebirth" type="datebirth" name="dob" id="datebirth" placeholder="Date of birth" required/>
			</li>
			<li>

				<input class="Pin" type="pin" name="password" id="pin" placeholder="Password" required/>
			</li>
			
				</ul>
				<button type="submit">Sign Up</button>
			</form>
		</div>
	</div>
