<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> 
<html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>CheckOut | Business Calender</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
		
        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	
		<link rel="stylesheet" href="css/font-awesome.min.css"/>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
        <link rel="stylesheet" href="css/main.css"/>
        <script type="text/javascript" src="js/script.js"></script>


        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,400,300,600,700' rel='stylesheet' type='text/css'>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <!-- Add your site or application content here -->

		<!-- end header top section -->

		<div class="header_middle_area">
			<div class="container">
				<div class="rwo middle_row">
					<div class="col-lg-2">
						
					</div>
					<div class="col-lg-6">
					   <div id="custom-search-input">
                           
                                <span class="input-group-btn">
                                    
                                        <span><i class="fa fa-search"></i></span>
                                    </button>
                                </span>
                            </div>
                        </div>
					</div>
					<div class="header_bottom_area">
        	<div class="container">
        		<div class="row">
        			<div class="col-lg-6">
        				<div class="nav-menu nav-pills pull-left mainmenu">
        					<ul class="nav navbar-nav">
								<li><a href="index.html">HOME</a></li>
								<li><a href="404.html">ABOUT</a></li>
								<li><a href="404.html">CONTACT</a></li>
								<li><a href="404.html">BLOG</a></li>
								<li><a href="404.html"></a></li>        
							</ul>
        				</div>
        			</div>
					<div class="col-lg-4">
						<div class="shop-menu pull-right mainmenu">
							<ul class="nav navbar-nav">
								<li><a href="#"><i class="fa fa-star"></i> Wishlist</a></li>
								<li><a href="checkout.html"><i class="fa fa-crosshairs"></i> Checkout</a></li>
								<li><a href="cart.html"><i class="fa fa-shopping-cart"></i> My Cart</a></li>
								<li><a href="signup.php"><i class="fa fa-shopping-cart"></i> Sign Up</a></li>
								<li><a href="admin/admin_login.php"><i class="fa fa-shopping-cart"></i> Admin Login</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- end header middle section -->

		

		<div class="container">
		    <div class="omb_login">
		    	<h3 class="omb_authTitle">Login or <a href="#">Sign up</a></h3>
				<div class="row omb_row-sm-offset-3 omb_socialButtons">
		    	    <div class="col-xs-4 col-sm-2">
				        <a href="#" class="btn btn-lg btn-block omb_btn-facebook">
					        <i class="fa fa-facebook visible-xs"></i>
					        <span class="hidden-xs">Facebook</span>
				        </a>
			        </div>
		        	<div class="col-xs-4 col-sm-2">
				        <a href="#" class="btn btn-lg btn-block omb_btn-twitter">
					        <i class="fa fa-twitter visible-xs"></i>
					        <span class="hidden-xs">Twitter</span>
				        </a>
			        </div>	
		        	<div class="col-xs-4 col-sm-2">
				        <a href="#" class="btn btn-lg btn-block omb_btn-google">
					        <i class="fa fa-google-plus visible-xs"></i>
					        <span class="hidden-xs">Google+</span>
				        </a>
			        </div>	
				</div>

				<div class="row omb_row-sm-offset-3 omb_loginOr">
					<div class="col-xs-12 col-sm-6">
						<hr class="omb_hrOr">
						<span class="omb_spanOr">or</span>
					</div>
				</div>

				<div class="row omb_row-sm-offset-3">
					<div class="col-xs-12 col-sm-6">	
					    <form class="omb_loginForm" action="logged.php" autocomplete="off" method="POST">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-user"></i></span>
								<input type="text" class="form-control" name="username" placeholder="Email ID">
							</div>
							<span class="help-block"></span>
												
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input  type="password" class="form-control" name="password" placeholder="Password">
							</div>

							<button style="margin-top:10px;" class="btn btn-lg btn-primary btn-block" type="submit">Login</button>
						</form>
					</div>
		    	</div>
				<!-- <div class="row omb_row-sm-offset-3">
					<div class="col-xs-12 col-sm-3">
						<label class="checkbox">
							<input type="checkbox" value="remember-me">Remember Me
						</label>
					</div>
					
                    <div class="col-xs-12 col-sm-3">
						<p class="omb_forgotPwd">
							<a href="#">Forgot password?</a>
						</p>
					</div>
				</div>	-->    	
			</div>
		</div>


                	
        <!-- footer area-->

        <div class="footer_area">
        	<div class="footer_top"><!-- footer top-->
        

        <script src="js/jquery-2.1.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/main.js"></script>
    </body>
</html>
