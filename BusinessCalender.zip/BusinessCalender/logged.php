<?php
session_start();
require('connect.php');

$_SESSION['pagemarker']='';
if((isset($_REQUEST['userid'])) || (isset($_REQUEST['password'])))
{
	$user = $_POST['username'];
	$pass = $_POST['password'];



	//searching admin
	$sql = "SELECT * FROM `user_login` WHERE id = ? AND password= ?";
	/*$result1 = $dbLink->query($sql);
	$count = $result1->num_rows;
*/
	$stmt = $dbLink->prepare($sql);
	$stmt->bind_param("is",$user,$pass);
	$stmt->execute();
	
	/* store result */
    $stmt->store_result();
	$count = $stmt->num_rows;
    //printf("Number of rows: %d.\n", $stmt->num_rows);
	

	if($count == 1)
	{
		$_SESSION['u_name'] = $user;
		$_SESSION['pagemarker']='login';
		//$_SESSION['password'] = $pass;
		// header('Location: admin.php');
		echo '<script type="text/javascript">';
		echo 'alert ("ok")';
		echo '</script>';
		header('Location: index.php');
		
	}
	else
	{
		
		echo ("<SCRIPT LANGUAGE='JavaScript'>
    		window.alert('Wrong email address or password.')
    		window.location.href='login.php';
    		</SCRIPT>");
		
		
	}

}





?>
